##### QUALITE DU PORTEFEUILLE
library(data.table)
library(tidyverse)
source("preparation.R")

# 
porte_f <- matrix(nrow = 8, ncol = 2)
porte_f[1,] = c("Encours des effets", abs(sum(data$EFFET)))
porte_f[2,] = c("Credits Court terme", abs(sum(data$CT)))
porte_f[3,] = c("Credit Moyen et Long terme", abs(sum(data$MT, data$LT)))
porte_f[4,] = c("Compte débiteurs", abs(sum(data$COMPTE1)))
porte_f[5,] = c("Impayes", abs(sum(data$IMPAYES)))

# calcul des restructures
data <- data %>%
  mutate(Restructures = TRESORERIE - DOUTEUX_292 - EFFET - COMPTE1 - CT - LT - MT - IMPAYES)
porte_f[6,] = c("Restructures", abs(sum(data$Restructures)))

# calcul des credits particuliers
part <- data %>%
  filter(!SEGMENT %in% c("GRDE ENTREPRISE","PME-PMI")) %>%
  summarise(va = sum(DOUTEUX_292)) %>%
  pull
porte_f[7,] = c("Credits Particuliers", abs(part))

# calcul des credits entreprises
entrp <- data %>%
  filter(SEGMENT %in% c("GRDE ENTREPRISE","PME-PMI")) %>%
  summarise(va = sum(DOUTEUX_292)) %>%
  pull
porte_f[8,] = c("Credits Entreprises", abs(entrp))

# labels de la table
colnames(porte_f) <- c("Intitutle", "Montant")
porte_f <- as.data.frame(porte_f)
porte_f$Montant <- as.numeric(porte_f$Montant)


##################### TOTAUX ##################
porte_f_tot <- matrix(nrow=3, ncol=2)
porte_f_tot[1,] <- c("Sain",sum(porte_f[1:5, 2]))
porte_f_tot[2,] <- c("Restructure",sum(porte_f[6,2]))
porte_f_tot[3,] <- c("Douteux et Litigieux",sum(porte_f[7:8,2]))
colnames(porte_f_tot) <- c("Intitutle", "Montant")
porte_f_tot <- as.data.frame(porte_f_tot)
porte_f_tot$Montant <- as.numeric(porte_f_tot$Montant)

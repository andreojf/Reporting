library(readxl)
library(tidyverse)
# recuperer tous les fichiers excel dans le dossier spécifié

# on récupère tous les fichiers
filespath <- "../FichiersExcel/" 

filepaths <- list.files(path="../FichiersExcel/",
               recursive=T,
               pattern=".xlsx",
              full.names=T)
filepaths


importFile <- function(filepath){
  df <- read_excel(path = filepath, 
                   sheet = "Situation Globale Retr",
                   skip = 8)
  df <- df[1:(nrow(df)-1),]
  df <- df %>%
    mutate(Pays = basename(dirname(filepath)))
  return(df)
}

df <- importFile("../FichiersExcel//NG/ENGAGEMENT_PORTEFEUILLE DE CBI NG au 31.12.2020.xlsx")

library(plyr)


filespath <- "../FichiersExcel/" 

filepaths <- list.files(path="../FichiersExcel/",
                        recursive=T,
                        pattern=".xlsx",
                        full.names=T)
df.list <- lapply(filepaths, importFile)
final.df <- rbind.fill(df.list)
